from django.urls import path

from .views import MailTemplateMasterView

urlpatterns = [
    path("mail-templates/", MailTemplateMasterView.as_view(), name="mail-templates"),
    path("mail-templates/<uuid:id>/", MailTemplateMasterView.as_view(), name="mail-templates"),

]