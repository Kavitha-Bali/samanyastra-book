from django.core.mail import EmailMultiAlternatives
from django.template import Template, Context

from celery import shared_task

from .backends import OutlookBackend
from .models import MailTemplateMaster, OutBounds
from .utils import get_object_or_none


@shared_task(bind=True)
def send_email(status, template_name, *to_mail, **context):
    """should not be called directly only call via send_email.delay"""

    mail_template = get_object_or_none(MailTemplateMaster, name=template_name)

    if mail_template is None:
        raise ValueError("Invalid mail template given")
   
    subject = mail_template.subject
    from_mail = mail_template.from_mail
    to_mail = to_mail
    template_string = mail_template.template 

    template = Template(template_string)
    mail_body = template.render(Context(context))

    msg = OutlookBackend(subject, mail_body, from_mail, to_mail)
    msg.send()

    mail_obj = OutBounds.objects.create( 
        mail_template=mail_template,
        to_mail=to_mail,
        body=mail_body
    )
    mail_obj.save()
    return True


@shared_task(bind=True)
def send_email_with_attachment(status, template_name, *to_mail, **context):

    mail_template = MailTemplateMaster.objects.get(name=template_name)

    subject = mail_template.subject
    from_mail = mail_template.from_mail
    to_mail = to_mail
    template_string = mail_template.template 
    template = Template(template_string)
    mail_body = template.render(Context(context))

    msg = EmailMultiAlternatives(subject,
                                 mail_body,
                                 from_mail,
                                 to_mail,
                                 cc=['hr@samanyastra.com']
                                 )
    msg.attach_alternative(mail_body, "text/html")
    msg.send()

    mail_obj = OutBounds.objects.create(
        mail_template=mail_template,
        to_mail=to_mail,
        body=mail_body
    )
    mail_obj.save()
    return True
