from django.db import models
import uuid


class BaseModel(models.Model):
    id = models.UUIDField(default=uuid.uuid4, primary_key=True, editable=False, unique=True, auto_created=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True, null=True)
    is_deleted = models.BooleanField(default=False)

    class Meta:
        abstract = True

class MailTemplateMaster(BaseModel):
    name = models.CharField(max_length=255)
    subject = models.CharField(max_length=255)
    template = models.TextField(default="")
    context = models.JSONField(default={})
    from_mail = models.EmailField()
    is_active = models.BooleanField(default=True)
    is_deleted = models.BooleanField(default=False)

    def __str__(self):
        return self.name
    
class OutBounds(BaseModel):
    mail_template = models.ForeignKey(MailTemplateMaster, on_delete=models.CASCADE)
    to_mail = models.EmailField()
    is_sent = models.BooleanField(default=False)
    body = models.TextField()

    def __str__(self):
        return self.mail_template.name