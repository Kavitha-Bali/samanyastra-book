from rest_framework.serializers import ModelSerializer

from .models import MailTemplateMaster, OutBounds


class MailTemplateMasterSerializer(ModelSerializer):
    class Meta:
        model = MailTemplateMaster
        fields = "__all__"