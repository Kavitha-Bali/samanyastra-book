from rest_framework.generics import GenericAPIView
from rest_framework.mixins import ListModelMixin, CreateModelMixin, DestroyModelMixin



from .models import MailTemplateMaster
from .serializers import MailTemplateMasterSerializer


class MailTemplateMasterView(GenericAPIView, ListModelMixin, CreateModelMixin, DestroyModelMixin): # noqa
    queryset = MailTemplateMaster.objects.all()
    serializer_class = MailTemplateMasterSerializer
    # permission_classes=
    lookup_field = 'id'

    def get(self, request, *args, **kwargs):
        return self.list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        return self.create(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        return self.destroy(request, *args, **kwargs)