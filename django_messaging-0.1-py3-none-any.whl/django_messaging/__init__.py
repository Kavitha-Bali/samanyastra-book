from django.conf  import settings

if  (settings.OUTLOOK_CLIENT_ID is None) or\
    (settings.OUTLOOK_CLIENT_SECRET is None) or\
    (settings.OUTLOOK_TENANT_ID is None) or\
    (settings.CELERY_BROKER_URL is None):
    raise ValueError("OUTLOOK_CLIENT_ID, OUTLOOK_CLIENT_SECRET, OUTLOOK_TENANT_ID are required to be configured in the settings")