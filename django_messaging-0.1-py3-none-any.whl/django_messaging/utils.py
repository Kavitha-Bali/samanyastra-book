from django.core.exceptions import ObjectDoesNotExist, MultipleObjectsReturned


def get_object_or_none(model_class, *args, **kwargs):
    try:
        return model_class.objects.get(**kwargs)
    except ObjectDoesNotExist:
        return None
    except MultipleObjectsReturned:
        return model_class.objects.filter(**kwargs).latest('created_at')