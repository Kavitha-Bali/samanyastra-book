import uuid
from django.conf import settings
from django.db import models
from django.utils import timezone


class RefreshToken(models.Model):
    """Server-side record of a local JWT refresh token for rotation and revocation."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="local_refresh_tokens",
    )
    jti = models.CharField(max_length=36, unique=True, help_text="JWT ID claim.")
    expires_at = models.DateTimeField()
    revoked_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def is_valid(self) -> bool:
        return self.revoked_at is None and self.expires_at > timezone.now()

    def __str__(self) -> str:
        return f"RefreshToken({self.user_id}, jti={self.jti[:8]}...)"
