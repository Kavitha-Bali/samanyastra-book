from django.urls import path

from .views import callback_view, health_check_view, initiate_login_view, logout_view, refresh_view


app_name = "sso_integration"

urlpatterns = [
    path("login-with-sso/", initiate_login_view, name="login-with-sso"),
    path("callback/", callback_view, name="callback"),
    path("refresh/", refresh_view, name="refresh"),
    path("logout/", logout_view, name="logout"),
    path("sso-integration-health/", health_check_view, name="health-check"),
]
