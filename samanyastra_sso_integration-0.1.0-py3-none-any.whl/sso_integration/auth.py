"""
JWT helpers for the Samanyastra SSO integration app.

Access token  — short-lived (default 15 min), stored in HttpOnly cookie.
Refresh token — long-lived (default 7 days), stored in HttpOnly cookie.
                Each refresh token has a unique JTI tracked in the DB
                for rotation and revocation.
"""

import uuid
from datetime import datetime, timedelta, timezone as dt_timezone

import jwt
from django.conf import settings
from django.contrib.auth import get_user_model

User = get_user_model()

_ALGORITHM = "HS256"


def issue_access_token(user: User, roles: list[str] | None = None, auth_source: str = "sso") -> str:
    now = datetime.now(dt_timezone.utc)
    payload = {
        "type": "access",
        "sub": user.username,
        "user_id": user.id,
        "email": user.email or "",
        "roles": roles or [],
        "auth_source": auth_source,
        "iat": now,
        "exp": now + timedelta(minutes=settings.JWT_ACCESS_EXPIRE_MINUTES),
    }
    return jwt.encode(payload, settings.JWT_SECRET, algorithm=_ALGORITHM)


def issue_refresh_token(user: User, roles: list[str] | None = None, auth_source: str = "sso") -> tuple[str, str]:
    """Returns (encoded_token, jti)."""
    jti = str(uuid.uuid4())
    now = datetime.now(dt_timezone.utc)
    payload = {
        "type": "refresh",
        "sub": user.username,
        "user_id": user.id,
        "roles": roles or [],
        "auth_source": auth_source,
        "jti": jti,
        "iat": now,
        "exp": now + timedelta(days=settings.JWT_REFRESH_EXPIRE_DAYS),
    }
    token = jwt.encode(payload, settings.JWT_SECRET, algorithm=_ALGORITHM)
    return token, jti


def decode_token(token: str) -> dict:
    """Decode and verify a JWT. Raises jwt.PyJWTError on failure."""
    return jwt.decode(token, settings.JWT_SECRET, algorithms=[_ALGORITHM])
