import secrets

import requests as http_client
from django.conf import settings
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_not_required
from django.http import HttpRequest, HttpResponse, JsonResponse
from django.shortcuts import redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from .auth import decode_token
from .models import RefreshToken
from .next_url import safe_next_url
from .session import clear_session, establish_session, revoke_refresh_token_cookie

User = get_user_model()


@login_not_required
def initiate_login_view(request: HttpRequest) -> HttpResponse:
    """Kicks off the Samanyastra SSO round trip.

    Embed this URL behind a "Login with Samanyastra" button on any host-app
    login page. Pass `?next=` to return the user to a specific URL afterward.
    """
    state = secrets.token_urlsafe(32)
    request.session["oauth_state"] = state

    next_url = safe_next_url(request, request.GET.get("next", ""))
    if next_url:
        request.session["login_next"] = next_url
    else:
        request.session.pop("login_next", None)

    qs = (
        f"app_id={settings.SAMANYASTRA_APP_ID}"
        f"&redirect_uri={settings.SAMANYASTRA_REDIRECT_URI}"
        f"&state={state}"
    )
    return redirect(f"{settings.SAMANYASTRA_AUTH_URL}/auth/login/?{qs}")


@login_not_required
def callback_view(request: HttpRequest) -> HttpResponse:
    """Samanyastra Auth redirects here after login.

    Exchanges the one-time code for identity, establishes a local session,
    and sends the user back to wherever they originally tried to reach (or
    settings.LOGIN_REDIRECT_URL if they came in through the login page directly).
    """
    expected_state = request.session.pop("oauth_state", None)
    received_state = request.GET.get("state", "")
    next_url = request.session.pop("login_next", "")
    error_ctx = {"login_url": settings.LOGIN_URL}

    if not expected_state or expected_state != received_state:
        return render(request, "sso_integration/error.html",
                      {**error_ctx, "message": "Invalid state parameter. Please try again."})

    code = request.GET.get("code", "")
    if not code:
        return render(request, "sso_integration/error.html",
                      {**error_ctx, "message": "No authorization code received from Samanyastra Auth."})

    try:
        resp = http_client.post(
            f"{settings.SAMANYASTRA_AUTH_URL}/auth/token/",
            json={
                "app_id": settings.SAMANYASTRA_APP_ID,
                "app_secret": settings.SAMANYASTRA_APP_SECRET,
                "code": code,
                "redirect_uri": settings.SAMANYASTRA_REDIRECT_URI,
            },
            timeout=10,
        )
    except http_client.RequestException:
        return render(request, "sso_integration/error.html",
                      {**error_ctx, "message": "Could not reach Samanyastra Auth. Please try again."})

    if resp.status_code != 200:
        return render(request, "sso_integration/error.html",
                      {**error_ctx, "message": f"Authentication failed: {resp.json().get('error', 'unknown')}"})

    user_data = resp.json()
    user, _ = User.objects.get_or_create(
        username=user_data["username"],
        defaults={"email": user_data.get("email", ""), "is_active": True},
    )
    if not user.is_active:
        return render(request, "sso_integration/error.html",
                      {**error_ctx, "message": "Your account is inactive."})

    response_obj = redirect(next_url or settings.LOGIN_REDIRECT_URL)
    establish_session(response_obj, user, auth_source="sso", roles=user_data.get("roles", []))
    return response_obj


@login_not_required
@require_POST
def refresh_view(request: HttpRequest) -> JsonResponse:
    """Rotates the JWT pair using the refresh_token cookie.

    Exempt from the login gate on purpose: this is exactly what a host app
    calls once the access token has already expired, when request.user is
    anonymous.
    """
    raw = request.COOKIES.get("refresh_token")
    if not raw:
        return JsonResponse({"error": "No refresh token cookie"}, status=401)
    try:
        payload = decode_token(raw)
    except Exception:
        return JsonResponse({"error": "Invalid or expired refresh token"}, status=401)

    if payload.get("type") != "refresh":
        return JsonResponse({"error": "Wrong token type"}, status=401)

    jti = payload.get("jti", "")
    record = RefreshToken.objects.filter(jti=jti).select_related("user").first()
    if not record or not record.is_valid():
        return JsonResponse({"error": "Refresh token revoked or expired"}, status=401)

    record.revoked_at = timezone.now()
    record.save(update_fields=["revoked_at"])

    resp = JsonResponse({
        "message": "Tokens rotated successfully.",
        "access_expires_in": settings.JWT_ACCESS_EXPIRE_MINUTES * 60,
    })
    establish_session(
        resp, record.user,
        auth_source=payload.get("auth_source", "sso"),
        roles=payload.get("roles", []),
    )
    return resp


@login_not_required
def logout_view(request: HttpRequest) -> HttpResponse:
    """Clears the local JWT session and sends the user back to the login page.

    Host apps can point their own logout link here, or call
    clear_session()/revoke_refresh_token_cookie() directly for more control
    over the response (e.g. a custom "you've been logged out" page).
    """
    revoke_refresh_token_cookie(request.COOKIES.get("refresh_token", ""))
    resp = redirect(settings.LOGIN_URL)
    clear_session(resp)
    return resp


_REQUIRED_SETTINGS = (
    "LOGIN_URL",
    "LOGIN_REDIRECT_URL",
    "SAMANYASTRA_AUTH_URL",
    "SAMANYASTRA_APP_ID",
    "SAMANYASTRA_APP_SECRET",
    "SAMANYASTRA_REDIRECT_URI",
    "JWT_SECRET",
    "JWT_ACCESS_EXPIRE_MINUTES",
    "JWT_REFRESH_EXPIRE_DAYS",
)


@login_not_required
def health_check_view(request: HttpRequest) -> JsonResponse:
    """
    GET /sso-integration-health/

    Self-check for this app's Samanyastra SSO integration:
      1. every setting the integration needs is present and non-empty
      2. this app's app_id/secret/redirect_uri are actually registered and
         valid against the central Samanyastra Auth service (via
         GET /auth/apps/verify/ — no auth code spent)

    Returns HTTP 200 when everything checks out, 503 otherwise — safe to
    wire into a monitoring/readiness probe. The startup system check in
    apps.py already hard-fails the process if LOGIN_URL/LOGIN_REDIRECT_URL
    are missing; this endpoint covers the full picture at request time,
    including the SAMANYASTRA_*/JWT_* settings that only have soft defaults.
    """
    missing = [name for name in _REQUIRED_SETTINGS if not getattr(settings, name, None)]
    settings_check = {"status": "ok" if not missing else "error", "missing": missing}

    if missing:
        # Nothing meaningful to verify against central without a real
        # app_id/secret/redirect_uri — fail fast instead of guessing.
        return JsonResponse({
            "status": "error",
            "checks": {
                "settings": settings_check,
                "central_registration": {"status": "skipped", "reason": "settings incomplete"},
            },
        }, status=503)

    try:
        resp = http_client.get(
            f"{settings.SAMANYASTRA_AUTH_URL}/auth/apps/verify/",
            params={
                "app_id": settings.SAMANYASTRA_APP_ID,
                "app_secret": settings.SAMANYASTRA_APP_SECRET,
                "redirect_uri": settings.SAMANYASTRA_REDIRECT_URI,
            },
            timeout=5,
        )
    except http_client.RequestException as exc:
        registration_check = {
            "status": "error",
            "reason": f"Could not reach Samanyastra Auth at {settings.SAMANYASTRA_AUTH_URL}: {exc}",
        }
    else:
        if resp.status_code != 200:
            registration_check = {
                "status": "error",
                "reason": f"Samanyastra Auth returned HTTP {resp.status_code}",
            }
        else:
            data = resp.json()
            all_ok = all(data.get(k) for k in (
                "app_registered", "app_active", "secret_valid", "redirect_uri_registered"
            ))
            registration_check = {"status": "ok" if all_ok else "error", **data}

    overall_ok = registration_check["status"] == "ok"
    return JsonResponse({
        "status": "ok" if overall_ok else "error",
        "checks": {
            "settings": settings_check,
            "central_registration": registration_check,
        },
    }, status=200 if overall_ok else 503)