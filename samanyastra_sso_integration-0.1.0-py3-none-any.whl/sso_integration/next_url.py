from django.http import HttpRequest
from django.utils.http import url_has_allowed_host_and_scheme


def safe_next_url(request: HttpRequest, candidate: str) -> str:
    """Only follow `next` if it's a same-site path — blocks open-redirect abuse.

    Shared by the SSO views here and by any host-app login view, so "where do
    we send the user back to" is validated the same way regardless of which
    login method they used.
    """
    if candidate and url_has_allowed_host_and_scheme(
        candidate, allowed_hosts={request.get_host()}, require_https=request.is_secure()
    ):
        return candidate
    return ""
