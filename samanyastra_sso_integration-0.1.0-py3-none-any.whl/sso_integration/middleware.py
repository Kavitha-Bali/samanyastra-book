"""
JWTCookieMiddleware
Reads the access_token HttpOnly cookie on every request.
If valid, injects the corresponding Django User into request.user,
replacing the default AnonymousUser set by AuthenticationMiddleware.
"""

import jwt
from django.contrib.auth import get_user_model
from django.conf import settings

User = get_user_model()


class JWTCookieMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        raw = request.COOKIES.get("access_token")
        if raw:
            try:
                payload = jwt.decode(raw, settings.JWT_SECRET, algorithms=["HS256"])
                if payload.get("type") == "access":
                    user = User.objects.filter(
                        username=payload["sub"], is_active=True
                    ).first()
                    if user:
                        request.user = user
            except jwt.PyJWTError:
                pass  # expired or tampered — leave as AnonymousUser
        return self.get_response(request)
