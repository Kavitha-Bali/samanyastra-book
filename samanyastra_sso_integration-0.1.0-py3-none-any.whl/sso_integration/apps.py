from django.apps import AppConfig


class SsoIntegrationConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "sso_integration"
    verbose_name = "Samanyastra SSO Integration"

    def ready(self):
        from django.conf import settings
        from django.core.checks import Error, register

        @register()
        def check_required_settings(app_configs, **kwargs):
            errors = []
            if not getattr(settings, "LOGIN_URL", None):
                errors.append(Error(
                    "LOGIN_URL is not configured. Set DJANGO_LOGIN_URL in the "
                    "environment so unauthenticated users know where to sign in.",
                    id="sso_integration.E001",
                ))
            if not getattr(settings, "LOGIN_REDIRECT_URL", None):
                errors.append(Error(
                    "LOGIN_REDIRECT_URL is not configured. Set "
                    "DJANGO_LOGIN_REDIRECT_URL in the environment so login knows "
                    "where to land when there's no 'next' URL to return to.",
                    id="sso_integration.E002",
                ))
            return errors
