"""
Session establishment — the one place that decides how an authenticated
identity becomes a local session (currently: a JWT access/refresh cookie
pair). Both the Samanyastra SSO callback (views.py, this app) and a host
app's own local-login view call establish_session() once credentials are
verified, so session mechanics stay identical no matter which login method
the user picked.
"""

from datetime import timedelta

from django.conf import settings
from django.http import HttpResponse
from django.utils import timezone

from .auth import decode_token, issue_access_token, issue_refresh_token
from .models import RefreshToken


def establish_session(response: HttpResponse, user, *, auth_source: str, roles: list[str] | None = None) -> None:
    """Issue a fresh JWT access/refresh pair for `user` and set them as cookies on `response`."""
    access_token = issue_access_token(user, roles, auth_source)
    refresh_token_str, jti = issue_refresh_token(user, roles, auth_source)
    RefreshToken.objects.create(
        user=user, jti=jti,
        expires_at=timezone.now() + timedelta(days=settings.JWT_REFRESH_EXPIRE_DAYS),
    )
    common = {"httponly": True, "samesite": "Lax", "secure": settings.SESSION_COOKIE_SECURE}
    response.set_cookie("access_token", access_token,
                        max_age=settings.JWT_ACCESS_EXPIRE_MINUTES * 60, **common)
    response.set_cookie("refresh_token", refresh_token_str,
                        max_age=settings.JWT_REFRESH_EXPIRE_DAYS * 86400, **common)


def clear_session(response: HttpResponse) -> None:
    response.delete_cookie("access_token")
    response.delete_cookie("refresh_token")


def revoke_refresh_token_cookie(raw_refresh_token: str) -> None:
    """Best-effort revoke: mark the refresh token's DB record revoked, if valid."""
    if not raw_refresh_token:
        return
    try:
        payload = decode_token(raw_refresh_token)
    except Exception:
        return
    jti = payload.get("jti", "")
    if jti:
        RefreshToken.objects.filter(jti=jti).update(revoked_at=timezone.now())
